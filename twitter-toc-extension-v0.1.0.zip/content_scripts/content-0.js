(()=>{"use strict";var e={611(e,t,i){e.exports={}},495(){let e=[],t=[],i=null;class n{constructor(){this.panel=null,this.isVisible=!1,this.isDragging=!1,this.dragOffset={x:0,y:0},this.defaultPosition={x:20,y:100}}async init(){let e=await chrome.storage.local.get("tocPanelPosition");this.position=e.tocPanelPosition||this.defaultPosition,this.create()}create(){this.panel&&this.panel.remove(),this.panel=document.createElement("div"),this.panel.id="twitter-toc-panel",this.panel.className="twitter-toc-panel",this.panel.style.cssText=`
      position: fixed;
      z-index: 999999;
      width: 280px;
      max-height: 60vh;
      background: var(--bg-primary, #ffffff);
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
      display: none;
      flex-direction: column;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `,this.panel.style.left=this.position.x+"px",this.panel.style.top=this.position.y+"px";let e=document.createElement("div");e.className="toc-panel-header",e.innerHTML=`
      <span class="drag-handle" title="Drag to move">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <circle cx="9" cy="6" r="1.5"/>
          <circle cx="15" cy="6" r="1.5"/>
          <circle cx="9" cy="12" r="1.5"/>
          <circle cx="15" cy="12" r="1.5"/>
          <circle cx="9" cy="18" r="1.5"/>
          <circle cx="15" cy="18" r="1.5"/>
        </svg>
      </span>
      <span class="panel-title">Contents</span>
      <button class="close-btn" title="Hide panel">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
          <path d="M14 1.41L12.59 0 7 5.59 1.41 0 0 1.41 5.59 7 0 12.59 1.41 14 7 8.41 12.59 14 14 12.59 8.41 7z"/>
        </svg>
      </button>
    `;let t=document.createElement("div");t.className="toc-panel-body",this.panel.appendChild(e),this.panel.appendChild(t),document.body.appendChild(this.panel),this.setupEventListeners(e)}setupEventListeners(e){let t=e.querySelector(".drag-handle"),i=e.querySelector(".close-btn");t.addEventListener("mousedown",e=>this.startDrag(e)),document.addEventListener("mousemove",e=>this.drag(e)),document.addEventListener("mouseup",()=>this.endDrag()),i.addEventListener("click",()=>this.hide())}startDrag(e){this.isDragging=!0;let t=this.panel.getBoundingClientRect();this.dragOffset.x=e.clientX-t.left,this.dragOffset.y=e.clientY-t.top,this.panel.classList.add("dragging"),e.preventDefault()}drag(e){if(!this.isDragging)return;let t=e.clientX-this.dragOffset.x,i=e.clientY-this.dragOffset.y,n=window.innerWidth-this.panel.offsetWidth-10,s=window.innerHeight-this.panel.offsetHeight-10;t=Math.max(10,Math.min(t,n)),i=Math.max(10,Math.min(i,s)),this.panel.style.left=t+"px",this.panel.style.top=i+"px"}endDrag(){this.isDragging&&(this.isDragging=!1,this.panel.classList.remove("dragging"),this.position={x:parseInt(this.panel.style.left),y:parseInt(this.panel.style.top)},chrome.storage.local.set({tocPanelPosition:this.position}))}show(e){this.panel||this.create();let t=this.panel.querySelector(".toc-panel-body");t.innerHTML=this.renderTOC(e),this.panel.style.display="flex",this.isVisible=!0,t.querySelectorAll(".toc-item").forEach((e,t)=>{e.addEventListener("click",()=>{o(t)})})}renderTOC(e){return e&&0!==e.length?`
      <ul class="toc-list">
        ${e.map((e,t)=>`
          <li class="toc-item level-${e.level}" data-index="${t}">
            ${e.text}
          </li>
        `).join("")}
      </ul>
    `:'<div class="toc-empty">No sections found</div>'}hide(){this.panel&&(this.panel.style.display="none"),this.isVisible=!1,chrome.storage.local.set({tocPanelVisible:!1})}toggle(e){this.isVisible?this.hide():(this.show(e),chrome.storage.local.set({tocPanelVisible:!0}))}destroy(){this.panel&&(this.panel.remove(),this.panel=null)}}function s(){let e=document.querySelector("article");if(!e)return[];let i=[];t=[];let n=null,s=document.querySelector('[data-testid="twitter-article-title"]');if(!s){for(let e of document.querySelectorAll("h1"))if(!e.closest("nav")&&!e.closest("footer")&&!e.closest("header")){let t=e.textContent?.trim();if(t&&t.length>=2&&!/^\d+$/.test(t)&&t.length<200){s=e;break}}}return s&&(n=s.textContent?.trim()),n&&n.length>=2&&!/^\d+$/.test(n)&&(t.push({id:"toc-header-title",element:s,text:n,level:1}),i.push({id:"toc-header-title",text:n,level:1})),e.querySelectorAll("h2, h3, h4, h5, h6").forEach((e,n)=>{if(e.closest("nav")||e.closest("footer")||e.closest("header"))return;let s=e.textContent?.trim();if(!s||s.length<2||/^\d+$/.test(s))return;let o=parseInt(e.tagName.charAt(1)),l=`toc-header-${n}`;t.push({id:l,element:e,text:s,level:o}),i.push({id:l,text:s,level:o})}),i}function o(e){let i=t[e];if(i&&i.element){let e=i.element.getBoundingClientRect(),t=window.pageYOffset||document.documentElement.scrollTop,n=e.top+t-70;window.scrollTo({top:n,behavior:"smooth"}),i.element.style.transition="background-color 0.3s ease",i.element.style.backgroundColor="rgba(29, 155, 240, 0.2)",setTimeout(()=>{i.element.style.backgroundColor=""},2e3)}}async function l(){setTimeout(()=>{e=s()},1500),i=new n,await i.init(),(await chrome.storage.local.get("tocPanelVisible")).tocPanelVisible&&e.length>0&&i.show(e),new MutationObserver(t=>{clearTimeout(window.tocExtractTimeout),window.tocExtractTimeout=setTimeout(()=>{e=s(),i.isVisible&&i.show(e)},1e3)}).observe(document.body,{childList:!0,subtree:!0})}chrome.runtime.onMessage.addListener((t,n,l)=>("getTOC"===t.action?l({toc:e=s(),isPanelVisible:i?.isVisible||!1}):"scrollTo"===t.action?(o(t.index),l({success:!0})):"togglePanel"===t.action?(e=s(),i.toggle(e),l({isVisible:i.isVisible})):"showPanel"===t.action?(e=s(),i.show(e),l({isVisible:!0})):"hidePanel"===t.action&&(i.hide(),l({isVisible:!1})),!0)),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",l):l();try{!function(e,t){if("function"!=typeof e){try{console.warn("[extension.js] content script default export must be a function; skipping mount")}catch(e){}return}(function(e,t){try{if("u"<typeof document||"document_start"===e)return t(),function(){};var i=!1;function n(){return"document_end"===e?"interactive"===document.readyState||"complete"===document.readyState:"document_idle"===e?"loading"!==document.readyState:"complete"===document.readyState}if(n())return t(),function(){};var s=function(){try{if(i)return;n()&&(i=!0,document.removeEventListener("readystatechange",s),t())}catch(e){}};document.addEventListener("readystatechange",s)}catch(e){try{t()}catch(e){}return function(){}}})(t,function(){try{e()}catch(e){try{console.warn("[extension.js] content script default export failed to run",e)}catch(e){}}})}(function(){return()=>{i&&i.destroy()}},"document_idle")}catch(e){}}},t={};function i(n){var s=t[n];if(void 0!==s)return s.exports;var o=t[n]={exports:{}};return e[n](o,o.exports,i),o.exports}i.m=e,i.r=e=>{"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.rv=()=>"1.7.6",i.ruid="bundler=rspack@1.7.6",i(495),i(611)})();