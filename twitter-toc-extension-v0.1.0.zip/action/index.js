(()=>{"use strict";var e={888(e,t,n){e.exports={}},488(){document.addEventListener("DOMContentLoaded",async()=>{let e=document.getElementById("root"),[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(t?.url?.includes("x.com")||t?.url?.includes("twitter.com"))){e.innerHTML=`
      <div class="container">
        <div class="header">
          <h1>X & Twitter TOC</h1>
        </div>
        <div class="content">
          <p class="hint">Please use this extension on Twitter/X</p>
        </div>
      </div>
    `;return}try{var n,a,i;let r=await chrome.tabs.sendMessage(t.id,{action:"getTOC"});r&&r.toc&&r.toc.length>0?(n=r.toc,a=r.isPanelVisible,i=t.id,e.innerHTML=`
      <div class="container">
        <div class="header">
          <h1>Contents</h1>
          <button class="pin-icon-btn ${a?"active":""}" id="pinBtn" title="${a?"Unpin from screen":"Pin to screen"}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              ${a?`
              <path d="M12 17v5"/>
              <path d="M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89"/>
              <path d="m2 2 20 20"/>
              <path d="M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11"/>
              `:`
              <path d="M12 17v5"/>
              <path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>
              `}
            </svg>
          </button>
        </div>
        <ul class="toc-list">
          ${n.map((e,t)=>`
            <li class="toc-item level-${e.level}" data-index="${t}" data-id="${e.id}">
              <a href="#" class="toc-link">${e.text}</a>
            </li>
          `).join("")}
        </ul>
      </div>
    `,e.querySelectorAll(".toc-link").forEach(e=>{e.addEventListener("click",async e=>{e.preventDefault();let t=e.target.closest(".toc-item").dataset.index;await chrome.tabs.sendMessage(i,{action:"scrollTo",index:parseInt(t)})})}),document.getElementById("pinBtn").addEventListener("click",async()=>{await chrome.tabs.sendMessage(i,{action:"togglePanel"}),window.close()})):o("No table of contents found. Make sure you are on a long-form article.")}catch(e){o("Unable to get TOC. Please refresh the page and try again.")}function o(t){e.innerHTML=`
      <div class="container">
        <div class="header">
          <h1>X & Twitter TOC</h1>
        </div>
        <div class="content">
          <p class="empty">${t}</p>
        </div>
      </div>
    `}})}},t={};function n(a){var i=t[a];if(void 0!==i)return i.exports;var o=t[a]={exports:{}};return e[a](o,o.exports,n),o.exports}n.m=e,n.r=e=>{"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.rv=()=>"1.7.6",n.ruid="bundler=rspack@1.7.6",n(488),n(888)})();